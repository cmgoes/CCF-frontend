export const BuybackStatisticData = [
	{
		title: 'Buybacks',
		value:'# 10', 
		status: 0,
	},
	{
		title: 'Amount(USD)',
		value:'$ 690,234', 
		status: 0,
	},
	{
		title: 'Average(USD)',
		value:'$ 87,345', 
		status: 0,
	}
]
export const BuybackTransactionData = [
	{
		id: '#5331',
		name: '134.7',
		usd: '23443.7',
		date: '11-25-2021',
		hash: '0x3a695493',
	},
	{
		id: '#5332',
		name: '32.8',
		usd: '5434.2',
		date: '11-26-2021',
		hash: '0x3a695493',
	},
	{
		id: '#5333',
		name: '98.0',
		usd: '15342.7',
		date: '11-27-2021',
		hash: '0x3a695493',
	},
	{
		id: '#5334',
		name: '222.7',
		usd: '54634.9',
		date: '11-28-2021',
		hash: '0x3a695493',
	},
	{
		id: '#5335',
		name: '32.8',
		usd: '5434.2',
		date: '11-29-2021',
		hash: '0x3a695493',
	},
	
];